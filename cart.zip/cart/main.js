var x = document.getElementById("cart");

function opencart(){
    if (x.style.display ==="block"){
        x.style.display="none";
    }
    else{
        x.style.display="block";
    }
}
function closecart(){
    if(x.style.document=="none"){
        x.style.display="block";
    }
    else{
        x.style.display="none";
    }
}